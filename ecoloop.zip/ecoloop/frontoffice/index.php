<?php
// FRONT OFFICE – page d'accueil publique (visible sans connexion)
require_once __DIR__ . '/../includes/functions.php';
$user = current_user();
$recs = db()->query('SELECT * FROM recompenses WHERE actif = 1 AND stock > 0 ORDER BY cout_points ASC LIMIT 6')->fetchAll();
$mon = $user ? ($user['role'] === 'admin' ? 'backoffice/index.php' : 'frontoffice/recompenses.php') : 'login.php';
?>
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Récompenses · EcoLoop</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"></head>
<body>
<header class="pub-top">
  <a class="logo" href="<?= url('frontoffice/index.php') ?>"><span class="logo-word">Eco<span>Loop</span></span></a>
  <a class="btn btn-primary btn-sm" href="<?= url($mon) ?>"><?= $user ? 'Mon espace' : 'Connexion' ?></a>
</header>
<main class="pub-wrap">
  <section class="hero">
    <h1>Triez bien, gagnez des EcoPoints, échangez-les.</h1>
    <p>Chaque scan, signalement et collecte vous rapporte des points. Transformez-les en objets utiles pour le quotidien.</p>
    <a class="btn btn-lime" href="<?= url($mon) ?>"><?= $user ? 'Voir mes récompenses' : 'Commencer' ?></a>
  </section>

  <h2 class="sec-h-s">Comment ça marche</h2>
  <div class="steps">
    <div class="card step"><div class="num">1</div><h3>Gagnez des points</h3><p class="muted sm">Scannez un objet, signalez un problème ou terminez une collecte.</p></div>
    <div class="card step"><div class="num">2</div><h3>Choisissez une récompense</h3><p class="muted sm">Parcourez le catalogue et échangez vos EcoPoints.</p></div>
    <div class="card step"><div class="num">3</div><h3>Retirez-la</h3><p class="muted sm">Présentez votre code d'échange au point partenaire.</p></div>
  </div>

  <h2 class="sec-h-s gap-top">Quelques récompenses</h2>
  <div class="grid g3">
    <?php foreach ($recs as $r): ?>
      <article class="card reward"><?= reward_art($r) ?><h3><?= e($r['nom']) ?></h3><p class="muted sm"><?= e($r['description']) ?></p>
        <div class="reward-f"><b><?= icon('star', 16) ?> <?= fmt($r['cout_points']) ?> pts</b></div></article>
    <?php endforeach; ?>
  </div>
</main>
<footer class="pub-foot">EcoLoop · Projet universitaire · Module Récompenses &amp; Échanges</footer>
</body></html>
