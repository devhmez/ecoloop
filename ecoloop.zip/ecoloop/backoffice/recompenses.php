<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$pdo = db();

/* ---- Actions rapides (POST) : afficher/masquer, réapprovisionner ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle') {
        $pdo->prepare('UPDATE recompenses SET actif = 1 - actif WHERE id = ?')->execute([$id]);
        flash('Visibilité mise à jour.');
    } elseif ($action === 'restock') {
        $pdo->prepare('UPDATE recompenses SET stock = stock + 10 WHERE id = ?')->execute([$id]);
        flash('+10 unités ajoutées au stock.');
    } elseif ($action === 'delete') {
        $n = $pdo->prepare('SELECT COUNT(*) FROM echanges WHERE recompense_id = ?'); $n->execute([$id]);
        if ((int)$n->fetchColumn() > 0) {
            $pdo->prepare('UPDATE recompenses SET actif = 0 WHERE id = ?')->execute([$id]);
            flash('Cette récompense a déjà été échangée : elle est masquée au lieu d\'être supprimée.', 'warn');
        } else {
            $pdo->prepare('DELETE FROM recompenses WHERE id = ?')->execute([$id]);
            flash('Récompense supprimée.');
        }
    }
    redirect('backoffice/recompenses.php');
}

$rows = $pdo->query("SELECT r.*, c.nom AS categorie,
    (SELECT COUNT(*) FROM echanges e WHERE e.recompense_id = r.id AND e.statut <> 'annule') AS nb_echanges
  FROM recompenses r LEFT JOIN categories_recompenses c ON c.id = r.categorie_id ORDER BY r.id DESC")->fetchAll();

$pageTitle = 'Récompenses'; $area = 'admin'; $active = 'rec';
require __DIR__ . '/../includes/header.php';
?>
<div class="ph"><div><h1>Récompenses</h1><p class="muted">Catalogue, stock et visibilité.</p></div>
  <a class="btn btn-primary" href="<?= url('backoffice/recompense_form.php') ?>"><?= icon('plus', 18) ?> Ajouter</a></div>
<div class="card pad">
  <?php if (!$rows): ?><div class="empty">Aucune récompense. Ajoute la première !</div><?php else: ?>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>Récompense</th><th>Catégorie</th><th>Coût</th><th>Stock</th><th>Échangée</th><th>Statut</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><div class="who"><?= reward_art($r, 'xs') ?><div><b><?= e($r['nom']) ?></b><span class="muted xs"><?= e($r['description']) ?></span></div></div></td>
        <td><?= e($r['categorie'] ?? '—') ?></td>
        <td><?= fmt($r['cout_points']) ?> pts</td>
        <td><b class="<?= $r['stock'] < 20 ? 'neg' : '' ?>"><?= (int)$r['stock'] ?></b></td>
        <td><?= (int)$r['nb_echanges'] ?></td>
        <td><?= $r['actif'] ? '<span class="badge ok"><i></i>Visible</span>' : '<span class="badge mute"><i></i>Masquée</span>' ?></td>
        <td><div class="acts">
          <a class="btn btn-sm btn-ghost" href="<?= url('backoffice/recompense_form.php?id=' . (int)$r['id']) ?>"><?= icon('edit', 15) ?> Modifier</a>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="restock"><button class="btn btn-sm btn-ghost" type="submit">+10 stock</button></form>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="toggle"><button class="btn btn-sm btn-ghost" type="submit"><?= $r['actif'] ? 'Masquer' : 'Afficher' ?></button></form>
          <form method="post" data-confirm="Supprimer « <?= e($r['nom']) ?> » ?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn btn-sm btn-danger" type="submit" aria-label="Supprimer"><?= icon('trash', 15) ?></button></form>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
