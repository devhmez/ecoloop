<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$pdo = db();

$kpi = $pdo->query("SELECT
  (SELECT COUNT(*) FROM recompenses) AS nb_rec,
  (SELECT COUNT(*) FROM echanges WHERE statut <> 'annule') AS nb_ech,
  (SELECT COALESCE(SUM(points_depenses),0) FROM echanges WHERE statut <> 'annule') AS pts_ech,
  (SELECT COUNT(*) FROM echanges WHERE statut = 'en_attente') AS nb_attente")->fetch();

$populaires = $pdo->query("SELECT r.nom, r.icone, r.teinte, COUNT(e.id) AS nb
  FROM recompenses r LEFT JOIN echanges e ON e.recompense_id = r.id AND e.statut <> 'annule'
  GROUP BY r.id ORDER BY nb DESC, r.nom LIMIT 5")->fetchAll();

$recents = $pdo->query("SELECT e.*, u.nom AS utilisateur, r.nom AS recompense
  FROM echanges e JOIN utilisateurs u ON u.id = e.utilisateur_id JOIN recompenses r ON r.id = e.recompense_id
  ORDER BY e.date_echange DESC LIMIT 6")->fetchAll();

$stocks = $pdo->query('SELECT nom, stock FROM recompenses WHERE actif = 1 AND stock < 20 ORDER BY stock')->fetchAll();

$pageTitle = 'Tableau de bord'; $area = 'admin'; $active = 'dash';
require __DIR__ . '/../includes/header.php';
?>
<div class="ph"><div><h1>Tableau de bord</h1><p class="muted">Vue d'ensemble du module récompenses.</p></div></div>
<div class="kpis">
  <div class="card stat"><div class="stat-ic"><?= icon('gift') ?></div><div class="stat-v"><?= fmt($kpi['nb_rec']) ?></div><div class="stat-l">Récompenses au catalogue</div></div>
  <div class="card stat"><div class="stat-ic"><?= icon('truck') ?></div><div class="stat-v"><?= fmt($kpi['nb_ech']) ?></div><div class="stat-l">Échanges (hors annulés)</div></div>
  <div class="card stat"><div class="stat-ic"><?= icon('star') ?></div><div class="stat-v"><?= fmt($kpi['pts_ech']) ?></div><div class="stat-l">Points échangés</div></div>
  <div class="card stat"><div class="stat-ic"><?= icon('clock') ?></div><div class="stat-v"><?= fmt($kpi['nb_attente']) ?></div><div class="stat-l">Échanges en attente</div></div>
</div>

<div class="grid two gap-top">
  <div class="card pad">
    <div class="card-h"><h3>Derniers échanges</h3><a class="btn btn-sm btn-ghost" href="<?= url('backoffice/echanges.php') ?>">Tout voir</a></div>
    <?php if (!$recents): ?><div class="empty">Aucun échange.</div><?php else: ?>
    <div class="tbl-wrap"><table class="tbl"><tbody>
      <?php foreach ($recents as $x): ?>
        <tr><td><b><?= e($x['utilisateur']) ?></b><br><span class="muted xs"><?= e($x['recompense']) ?> · <?= fmt_date($x['date_echange']) ?></span></td><td><?= badge_statut($x['statut']) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div>
  <div class="stack">
    <div class="card pad">
      <div class="card-h"><h3>Les plus demandées</h3></div>
      <ul class="stack" style="gap:10px">
        <?php foreach ($populaires as $p): ?>
          <li class="who"><?= reward_art($p, 'xs') ?><div style="flex:1"><b><?= e($p['nom']) ?></b></div><span class="muted"><?= (int)$p['nb'] ?> échange(s)</span></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="card pad">
      <div class="card-h"><h3>Stocks faibles</h3></div>
      <?php if (!$stocks): ?><p class="muted sm">Tous les stocks sont suffisants.</p><?php else: ?>
      <ul class="stack" style="gap:8px"><?php foreach ($stocks as $s): ?>
        <li class="row between"><span><?= e($s['nom']) ?></span><b class="<?= $s['stock'] == 0 ? 'neg' : 'stock-low' ?>"><?= (int)$s['stock'] ?></b></li>
      <?php endforeach; ?></ul><?php endif; ?>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
