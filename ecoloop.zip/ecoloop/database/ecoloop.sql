-- =====================================================================
-- EcoLoop : module "Récompenses & Échanges"
-- Import : phpMyAdmin > Importer  (ou onglet SQL > coller ce fichier)
-- =====================================================================
CREATE DATABASE IF NOT EXISTS ecoloop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecoloop;

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW  IF EXISTS v_classement;
DROP TABLE IF EXISTS utilisateurs_badges, badges, historique_points, echanges, recompenses, categories_recompenses, utilisateurs;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- Utilisateurs (table minimale : à fusionner avec celle de tes collègues) ----------
CREATE TABLE utilisateurs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('citoyen','admin') NOT NULL DEFAULT 'citoyen',
  quartier VARCHAR(100) DEFAULT NULL,
  points INT UNSIGNED NOT NULL DEFAULT 0,
  statut ENUM('actif','suspendu') NOT NULL DEFAULT 'actif',
  date_inscription DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Catégories de récompenses ----------
CREATE TABLE categories_recompenses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------- Catalogue ----------
CREATE TABLE recompenses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(120) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  cout_points INT UNSIGNED NOT NULL,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  icone VARCHAR(20) NOT NULL DEFAULT 'gift',
  teinte ENUM('a','b','c') NOT NULL DEFAULT 'a',
  categorie_id INT UNSIGNED DEFAULT NULL,
  actif TINYINT(1) NOT NULL DEFAULT 1,
  date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rec_cat FOREIGN KEY (categorie_id) REFERENCES categories_recompenses(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Échanges (une ligne = un échange de points contre une récompense) ----------
CREATE TABLE echanges (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL UNIQUE,
  utilisateur_id INT UNSIGNED NOT NULL,
  recompense_id INT UNSIGNED NOT NULL,
  points_depenses INT UNSIGNED NOT NULL,
  statut ENUM('en_attente','valide','remis','annule') NOT NULL DEFAULT 'en_attente',
  date_echange DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  date_maj DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ech_user FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
  CONSTRAINT fk_ech_rec  FOREIGN KEY (recompense_id)  REFERENCES recompenses(id)  ON DELETE RESTRICT,
  INDEX idx_ech_user (utilisateur_id),
  INDEX idx_ech_statut (statut)
) ENGINE=InnoDB;

-- ---------- Historique des points (gains, dépenses, remboursements) ----------
CREATE TABLE historique_points (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  utilisateur_id INT UNSIGNED NOT NULL,
  type ENUM('gain','depense','remboursement') NOT NULL,
  points INT NOT NULL,                 -- positif pour gain/remboursement, négatif pour dépense
  description VARCHAR(200) NOT NULL,
  echange_id INT UNSIGNED DEFAULT NULL,
  date_operation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_user FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
  CONSTRAINT fk_hist_ech  FOREIGN KEY (echange_id) REFERENCES echanges(id) ON DELETE SET NULL,
  INDEX idx_hist_user (utilisateur_id, date_operation)
) ENGINE=InnoDB;

-- ---------- Badges ----------
CREATE TABLE badges (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(80) NOT NULL,
  description VARCHAR(200) NOT NULL,
  icone VARCHAR(20) NOT NULL DEFAULT 'award'
) ENGINE=InnoDB;

CREATE TABLE utilisateurs_badges (
  utilisateur_id INT UNSIGNED NOT NULL,
  badge_id INT UNSIGNED NOT NULL,
  progression TINYINT UNSIGNED NOT NULL DEFAULT 0,   -- 0 à 100 ; 100 = badge obtenu
  date_obtention DATETIME DEFAULT NULL,
  PRIMARY KEY (utilisateur_id, badge_id),
  CONSTRAINT fk_ub_user  FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
  CONSTRAINT fk_ub_badge FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Vue : classement (RANK() nécessite MariaDB 10.2+ : OK avec XAMPP récent) ----------
CREATE VIEW v_classement AS
SELECT id, nom, quartier, points,
       RANK() OVER (ORDER BY points DESC) AS rang
FROM utilisateurs
WHERE role = 'citoyen' AND statut = 'actif';

-- =====================================================================
-- DONNÉES DE DÉMO   (mot de passe de tous les comptes : password)
-- =====================================================================
INSERT INTO utilisateurs (nom, email, mot_de_passe, role, quartier, points, statut, date_inscription) VALUES
('Administrateur EcoLoop','admin@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin','Tunis',0,'actif','2026-01-05 09:00:00'),
('Amira Ben Salah','amira@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','Ariana',850,'actif','2026-02-10 10:00:00'),
('Sana Khelifi','sana@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','Les Berges du Lac',1240,'actif','2026-01-12 10:00:00'),
('Mehdi Bouzid','mehdi@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','Ariana',1105,'actif','2026-01-20 10:00:00'),
('Ines Trabelsi','ines@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','La Marsa',790,'actif','2026-03-02 10:00:00'),
('Karim Ayari','karim@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','El Menzah',745,'actif','2026-03-15 10:00:00'),
('Lina Mejri','lina@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','Carthage',620,'actif','2026-04-04 10:00:00'),
('Walid Sassi','walid@ecoloop.tn','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','citoyen','Ben Arous',410,'suspendu','2026-04-18 10:00:00');

INSERT INTO categories_recompenses (nom) VALUES ('Accessoires'),('Maison & jardin'),('Bons d''achat'),('Énergie');

INSERT INTO recompenses (nom, description, cout_points, stock, icone, teinte, categorie_id) VALUES
('Sac tote en coton bio','Un sac réutilisable solide pour le marché.',350,120,'gift','a',1),
('Set de couverts en bambou','Fourchette, couteau, cuillère et pochette de voyage.',450,85,'leaf','b',1),
('Gourde en inox réutilisable','Gourde isotherme de 500 ml, garde le froid.',600,64,'droplet','c',1),
('Kit de compostage maison','Bac, mélange et fiche explicative.',900,31,'recycle','a',2),
('Bon d''achat · 20 TND','Valable chez les magasins partenaires.',1200,200,'star','b',3),
('Chargeur solaire pour téléphone','Panneau de poche avec sortie USB.',1500,18,'zap','c',4);

INSERT INTO badges (titre, description, icone) VALUES
('Premier scan','Vous avez scanné votre premier objet','scan'),
('Dix collectes','10 collectes terminées','truck'),
('Gardien du verre','5 kg de verre triés','glass'),
('Lève-tôt','5 collectes avant 10h00','clock'),
('Club des 50 kg','50 kg recyclés au total','award'),
('Semaine sans plastique','7 jours sans plastique','bottle');

INSERT INTO utilisateurs_badges (utilisateur_id, badge_id, progression, date_obtention) VALUES
(2,1,100,'2026-02-12 11:00:00'),(2,2,100,'2026-08-01 11:00:00'),(2,3,100,'2026-06-10 11:00:00'),
(2,4,100,'2026-07-02 08:30:00'),(2,5,85,NULL),(2,6,43,NULL),
(3,1,100,'2026-01-14 11:00:00'),(3,2,100,'2026-07-01 11:00:00');

INSERT INTO echanges (code, utilisateur_id, recompense_id, points_depenses, statut, date_echange) VALUES
('ECO-DEMO01',2,2,450,'remis','2026-11-09 14:20:00');

INSERT INTO historique_points (utilisateur_id, type, points, description, echange_id, date_operation) VALUES
(2,'gain',60,'Collecte C-1040 terminée',NULL,'2026-11-14 10:00:00'),
(2,'gain',10,'Scan d''une canette en aluminium',NULL,'2026-11-12 18:10:00'),
(2,'depense',-450,'Échange : Set de couverts en bambou',1,'2026-11-09 14:20:00'),
(2,'gain',25,'Signalement R-2036 résolu',NULL,'2026-11-17 09:00:00');
