<?php
// Chauffeur : ma tournée (collectes assignées, démarrage et fin de collecte)
require_once __DIR__ . '/../includes/auth.php';
$user = require_login(['driver'], '../');
$pdo  = db();
$collectorId = (int)$user['collector_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    // Le chauffeur ne peut agir que sur SES collectes
    $st = $pdo->prepare("SELECT * FROM collections WHERE id = ? AND collector_id = ?");
    $st->execute([$id, $collectorId]);
    $col = $st->fetch();

    if (!$col) {
        flash('This pickup is not assigned to you.', 'bad');
    } elseif ($action === 'start') {
        if ($col['status'] !== 'Scheduled') {
            flash("{$col['code']} cannot be started.", 'bad');
        } elseif (!$col['vehicle_id']) {
            flash("{$col['code']} has no vehicle yet. Ask the admin to assign one.", 'bad');
        } elseif ($col['pickup_date'] > date('Y-m-d')) {
            flash("{$col['code']} is planned for a later day.", 'bad');
        } else {
            $pdo->prepare("UPDATE collections SET status = 'On the way' WHERE id = ?")->execute([$id]);
            flash("{$col['code']}: you are on the way.");
        }
    } elseif ($action === 'complete') {
        if ($col['status'] !== 'On the way') {
            flash("{$col['code']} must be started before it is completed.", 'bad');
        } else {
            $pdo->prepare("UPDATE collections SET status = 'Completed' WHERE id = ?")->execute([$id]);
            flash("{$col['code']} collected. Well done!");
        }
    }
    redirect('index.php');
}

$st = $pdo->prepare(COLLECTION_SELECT . " WHERE c.collector_id = ? AND c.status IN ('Scheduled','On the way') "
    . COLLECTION_GROUP . " ORDER BY c.pickup_date, c.slot");
$st->execute([$collectorId]);
$rows = $st->fetchAll();

$today = date('Y-m-d');
$groups = ['Today' => [], 'Overdue' => [], 'Upcoming' => []];
foreach ($rows as $c) {
    if ($c['pickup_date'] === $today) $groups['Today'][] = $c;
    elseif ($c['pickup_date'] < $today) $groups['Overdue'][] = $c;
    else $groups['Upcoming'][] = $c;
}

$st = $pdo->prepare("SELECT COUNT(*) FROM collections WHERE collector_id = ? AND status = 'Completed' AND pickup_date = ?");
$st->execute([$collectorId, $today]);
$doneToday = (int)$st->fetchColumn();

$title = 'My route'; $active = 'route'; $root = '../';
include __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <div><h1>My route</h1><p class="muted">Hello <?= e($user['name']) ?>. Your assigned pickups and vehicles.</p></div>
  <div class="stat"><b><?= count($groups['Today']) ?></b><span class="muted sm">to do today</span></div>
  <div class="stat"><b><?= $doneToday ?></b><span class="muted sm">done today</span></div>
</div>

<?php if (!$rows): ?>
  <div class="card empty"><b>No pickups assigned</b><span class="muted">New assignments from the admin appear here.</span></div>
<?php endif; ?>

<?php foreach ($groups as $label => $list): if (!$list) continue; ?>
  <h3 class="group-title"><?= e($label) ?> <span class="muted">(<?= count($list) ?>)</span></h3>
  <?php foreach ($list as $c): ?>
    <article class="card">
      <div class="row between">
        <div><b><?= e(fmt_date($c['pickup_date'])) ?></b> <span class="muted">· <?= e($c['slot']) ?></span></div>
        <?= status_badge($c['status']) ?>
      </div>
      <div class="chips"><?= cats_badges($c['cats']) ?></div>
      <p><b><?= e($c['owner_name']) ?></b><br><span class="muted"><?= e($c['address']) ?></span></p>
      <?php if ($c['note']): ?><p class="note">“<?= e($c['note']) ?>”</p><?php endif; ?>
      <div class="who">
        <div><span class="lbl">Vehicle</span><b><?= e(vehicle_label($c['vehicle_code'], $c['vehicle_type'])) ?></b></div>
        <div><span class="lbl">Reference</span><b><?= e($c['code']) ?></b></div>
      </div>
      <?php if ($c['status'] === 'Scheduled'): ?>
        <?php if (!$c['vehicle_id']): ?>
          <p class="muted sm">Waiting for a vehicle to be assigned.</p>
        <?php elseif ($c['pickup_date'] > $today): ?>
          <p class="muted sm">You can start this pickup on its day.</p>
        <?php else: ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="start"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
            <button class="btn primary">Start: I'm on the way</button></form>
        <?php endif; ?>
      <?php else: ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="complete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
          <button class="btn primary">Mark as collected</button></form>
      <?php endif; ?>
    </article>
  <?php endforeach; ?>
<?php endforeach; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
